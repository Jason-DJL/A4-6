package service;

import model.dataccess.LoginDataAccess;
import model.entities.MessageException;
import model.entities.User;

import java.sql.SQLException;

public class LoginBusinessLayer {

    private static LoginBusinessLayer instance = null;

    private final LoginDataAccess loginDataAccess;

    private LoginBusinessLayer(LoginDataAccess loginDataAccess) {
        this.loginDataAccess = loginDataAccess;
    }

    public static LoginBusinessLayer getInstance() {
        if (instance == null) {
            instance = new LoginBusinessLayer(new LoginDataAccess());
        }
        return instance;
    }

    public void login(String userName, String password)
            throws SQLException, ClassNotFoundException {
        if (userName.isEmpty()) {
            throw new MessageException("Username not informed.");
        } else if (password.isEmpty()) {
            throw new MessageException("Password not informed.");
        }

        User user = new User(userName, password);

        if (!loginDataAccess.verifyCredentials(user)) {
            throw new MessageException("Incorrect credentials.");
        }
    }
}
